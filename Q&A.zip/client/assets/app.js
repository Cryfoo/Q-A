var app = angular.module("app", ["ngRoute"]);

app.config(function($routeProvider) {
	$routeProvider
	.when("/index", {
		templateUrl: "partials/login.html",
		controller: "loginController"
	})
	.when("/", {
		templateUrl: "partials/home.html",
		controller: "indexController"
	})
	.when("/new_question", {
		templateUrl: "partials/new_q.html",
		controller: "newQueController"
	})
	.when("/question/:id", {
		templateUrl: "partials/show.html",
		controller: "showController"
	})
	.when("/question/:id/new_answer", {
		templateUrl: "partials/new_a.html",
		controller: "newAnsController"
	})
	.otherwise({
		redirectTo: "/index"
	});
});