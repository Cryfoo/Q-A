app.controller("showController", ["$scope", "usersFactory", "questionsFactory", "$location", "$routeParams", function($scope, usersFactory, questionsFactory, $location, $routeParams) {
	usersFactory.getUser(function(user) {
		$scope.user = user;
	});
	questionsFactory.getQuestion($routeParams.id, function(question) {
		$scope.question = question;
	});
	questionsFactory.getAnswers($routeParams.id, function(answers) {
		$scope.answers = answers;
	});
	$scope.logout = function() {
		usersFactory.logout();
		$scope.user = null;
		$location.url("/index");
	}
}]);